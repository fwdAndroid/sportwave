import 'package:flutter/material.dart';

const colorWhite = Colors.white;
final textformColor = const Color(0xff6C757D);
final textformFillColor = const Color(0xffF6F7F9);
const mainBtnColor = Colors.blue;
final mobileBackgroundColor = const Color(0xff000080);
