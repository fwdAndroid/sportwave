import 'package:flutter/material.dart';

const black = Colors.black;
const colorwhite = Colors.white;
final borderColor = const Color(0xff3C4755);
final appBarColor = const Color(0xff141326);
final textColor = const Color(0xffE3823C);
final red = const Color(0xFFF95B51);
final c = const Color(0xFF666666);
final b = const Color(0xffE84040);
const g = Colors.green;
const kPrimaryColor = Color(0xFFFFC200);
const kTextcolor = Color(0xFF241424);
const kDarkButton = Color(0xFF372930);
