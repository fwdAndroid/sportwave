import 'package:get/get.dart';

class MainController extends GetxController {}